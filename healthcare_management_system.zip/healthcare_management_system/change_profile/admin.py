from django.contrib import admin

# Register your models here.
from .models import profile_master
admin.site.register(profile_master)